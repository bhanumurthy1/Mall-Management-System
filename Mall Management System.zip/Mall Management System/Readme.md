CHANGES MADE TO THE PROJECT

•	For each food stall, the administrator of the application will be able to add a food stall manager.
•	Administrator will be able to able to add/update/delete/view food stall managers
•	Food stall manager will be able to add/update/delete/view menu of the food stall assigned to them.
•	Food stall manager will be able to process the food orders of their respective food stall

CONTRIBUTIONS


•	Developed the View Job openings features from customer end that lets the customer get to know about the job opportunities present in the mall and their details.
•	Developed the View Job Applications features from customer end that lets the customer to know the status of applied job.
•	Developed the book parking space feature from customer perspective that lets the customer book a parking space in the selected parking lot at selected time slot.
•	Implemented parking feature from the admin perspective, where it lets the admin add new parking space to the application, manage parking lot and delete parking space.
•	Implemented gaming feature from the admin perspective, where it lets the admin add new game to the application, manage games and delete game.


•	Developed the book movie ticket feature from customer perspective that lets the customer book a ticket for the selected movie at selected time slot.
•	Developed the View shop specifics features from customer end that lets the customer get to know about the shops present at the mall and their details.
•	Developed the parking feature from the administrator perspective, where it lets the administrator manage the booked parking spaces.
•	Implemented food stalls feature from the admin perspective, where it lets the administrator add new food stalls to the application and food store manager to manage the food stalls and their menu details.
•	Also, worked on the login feature of the application.
•	Developed food stall manager feature, administrator of the application will be able to add/update/delete manager to the food stall. Food stall manager will be able to add/update/delete/view food menu of the stall assigned to them. Food stall manager is also reponsible for processing food order of their assigned food stall.



•   Developed the Parking Booking History feature of the application, where user can view their booked parking slots.
•   Implemented events feature from admin end, where administrator can view/add/update/delete the events happening in the mall.
•   Developed the events feature from user end, where user can view all the happening events and their details in the mall.
•   Implemented order food feature, where user can 
    Add the food menu item to the cart, 
    View the cart - Where user can increase/decrease the quantity which relatively changes the price and,
    Order the food.
•   Implemented Food Booking History feature, whre user can view 
    The ordered food item list,
    The order status of the food - Accepted or Rejected
    The delivery status of the food - Ready to pick up or not.
•   Implemented events feature from admin end, where administrator can view/add/update/delete the flash deals by choosing it as mega 
    deal or normal deal.
•   Worked on the registration feature of the application.


•	Implemented the admin end for processing food orders placed by the customers. This feature will let the admin accept/reject the orders and notify the customer once the order is ready to be picked.
•	Developed the admin end for the movie feature. The admin will be able to add a new movie and relevant information, Update and Delete the same. 
•	Worked on the Job Opportunities feature for the customer end. The applicant will be able to apply for a job opening by filling out a form and uploading a resume which will be submitted to the admin for review.
•	Developed the View and filter movies feature which let’s the user view all the streaming movies and filter based on preference.
•	Developed view feature for the user to view flash deals and mega deals.


•	Developed the shop specifics feature from the Administrator end, where the application enables the administrator to manage shops present at the mall and their details.
•	Developed the View parking lots, and parking spaces features from Customer end that enables the customers to view the availability of the parking lots and spaces in the mall.
•	Developed the view Food Stall and Menu features from the Customer end that enables the Customer to view various food stalls that are available in the mall and view menu items available in a specific food stall.
•	Developed the hamburger menu view which will display the list based on the category of the Administrator/ Food Admin/user.
•	Also worked on the view and update profile of the logged in user.


•	Designed the home page of the application with the functionality to navigating to the respective service when clicked on the any of the service 
•   Implemented the manage users for the admin end, where admin will be able to add a new user or update or delete an existing user.
•   Developed the Game feature from the customer end , where customer will be able to view all the games available and also get the detailed information along with the video of that particular game.
•   Implemented the Recharge card feature for the customer end, where customer an update the card balance.
•   Developed the Job feature from the admin end, where the admin will be able to view all the jobs, update or delete the existing job and can also add new job to the job list.
•   Implemented the Review applications for the admin end, admin has an option to view all the applied applications,  can accept or reject a appliction.
•   Implemented the movie booking history for the customer end, where the customer will be able to view the all past bookings and can also view the tickets for the each booking.
